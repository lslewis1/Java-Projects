/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package carapp;

import java.util.Scanner;

/**
 *
 * @author Logan
 */
public class CarApp {       // *** fix the Drive for car 2, needs to be able to add fuel

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        new CarApp();  // creates new car application
    }
   
    
    public CarApp() {
        
        Scanner scan = new Scanner(System.in);
        System.out.println("Please enter the color of the car: ");
        String carClr = scan.next();
        
        System.out.println("Please enter the maximum fuel capactiy of the car: ");
        double maxCap = scan.nextDouble();
        
        System.out.println("Please enter the current fuel level of the car: ");
        double fuel = scan.nextDouble();
        
        if(fuel > maxCap) {
           System.out.println("The fuel level cannot be greater than the tank's capacity.");
           fuel = maxCap; 
           System.out.println("The fuel level is now set at max (the tank is full).");
        }
         
        System.out.println("Please enter the mileage of the car: ");
        double mlg = scan.nextDouble();
        
        System.out.println("Please enter the miles per gallon of the car: ");
        double milesPerG = scan.nextDouble();
        
        System.out.println("What was the mileage when the tires were last changed? ");
        double lastChngMlg = scan.nextDouble();
        
        Car myCar = new Car(carClr, fuel, mlg, milesPerG, maxCap);   // creates a new car object, takes attributes in same order as Car constructor (based on user inputs)
        
        Car car2 = myCar.deepCopy();    // creates a new car with the same attributes as the first car object.
        
        if(!car2.getColor().equalsIgnoreCase("Blue")) {  // checks to see if the car is already blue, if not it changes to blue
            car2.changeColor("Blue");
        }
        else {
            car2.changeColor("Red");    // otherwise car 2 becomes red.
        }
        
        System.out.println();
        
        myCar.tireCondition(lastChngMlg);  // displays the tire condition of both cars.
        car2.tireCondition(lastChngMlg);
        
        System.out.println();
        
        myCar.drive(200);       // drives each car a set mileage
        
        if(car2.drive(500) == -1) {
            car2.drive(car2.getDrivingRange());    // empties the tank
            car2.addFuel(car2.getMaxCapacity());        // refills the tank to allow car 2 to finish the drive
            car2.drive(500 - car2.getDrivingRange());
        }
        else {
            car2.drive(500);
        }
        
        System.out.println();
        
        System.out.println("Car 1's attributes: " + myCar.ToString());       // the to string method prints out values for each car's attributes.
        System.out.println("Car 2's attributes: " + car2.ToString());
        
        // This next segment of code is not necessary for this lab.
        /*
        System.out.println("How far would you like to drive? ");
        double distance = scan.nextDouble();
        
        if (myCar.drive(distance) == -1) {
            System.out.println("You cannot drive that far.");
        }
        else {
            System.out.print("I hope you enjoyed your drive. Your current fuel level is");
            System.out.printf("%5.1f", + myCar.getFuelLevel());
            System.out.println(" gallons");
        }
        */
        
    }
}
