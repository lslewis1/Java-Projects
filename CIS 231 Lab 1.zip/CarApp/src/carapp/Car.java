/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package carapp;

/**
 *
 * @author Logan
 */
public class Car {      
   
    private double fuelLevel;   // in gallons
    private double mpg; // miles per gallon
    private double mileage; // miles traveled by car over time
    private String color;
    private double maxCapacity; // capacity of the gas tank
    
    public Car(String newColor, double newfuelLevel, double newMileage, double newMpg, double newMaxCap) { // Constructor takes class name, creates new car with user entered attributes.
        
        color = newColor;
        mpg = newMpg;
        fuelLevel = newfuelLevel;
        mileage = newMileage;
        maxCapacity = newMaxCap;
        
    }
    
    public Car() {  // default constructor
        
    }
    
    public String getColor() {
        return color;
    }
    
    public void changeColor(String newColor) {  // method to change color of car
        color = newColor;
    }
    
    public double getMileage() {
        return mileage;
    }
    
    public void setMileage(double newMiles) {
        mileage += newMiles;
    }
    
    public double getFuelLevel() {
        return fuelLevel;
    }
    
    public void setFuelLevel(double newFuelLevel) {
        fuelLevel = newFuelLevel;
    }
    
    public int addFuel(double fuelGallons) {    // returns errors if fuel cannot be added
        
        if (fuelGallons > maxCapacity) {
            return -1; // operation is unsuccessful.
        }
        else if ((fuelGallons + fuelLevel) > maxCapacity) {
            return -1; // operation is unsuccessful.
        }
        else {
            fuelLevel += fuelGallons;
            return 1;
        }
        
    }
    
    public void setMaxCapacity(double newMaxCap) {
        maxCapacity = newMaxCap;
    }
    
    public double getMaxCapacity() {
        return maxCapacity;
    }
    
    public double getDrivingRange() {   // the distance the car is able to travel with the mpgs and the fuel level.
        return mpg * fuelLevel;     // remaining miles available to travel
    }
    
    public Car deepCopy() {
        
        Car newCar = new Car(color, fuelLevel, mileage, mpg, maxCapacity);
        return newCar;
    }
    
    public  int drive(double howFar) { // how far the user wants to travel, cannot go over the maximum distance on one full tank, changes mileage and fuel level
        if (howFar > (mpg * maxCapacity)) {
            System.out.println(howFar + " miles is beyond the driving capabiltiy of this car on one full tank, the tank must be filled to finish the drive.");
            return -1;
        }
        else if (howFar > (mpg * fuelLevel)) {  
            System.out.println(howFar + " miles is beyond the driving capabiltiy of this car on the amount of fuel in the tank, add fuel.");
            return -1;
        }
        else {
            mileage += howFar;
            fuelLevel -= (howFar / mpg);
            return 1;
        }
            
    }
    
    public  void tireCondition(double lastMlg) {  // the variable lastMlg represents the last mileage where the tires were changed.
        
        if((mileage - lastMlg) >= 40000) {
            
            System.out.println("The tires need to be changed, they have driven at least 40000 miles.");   
        }
        
        else {
            System.out.println("The tires do not need to be changed yet, they have " + (40000 - (mileage - lastMlg)) + " miles left before they must be changed again.");
        }
    }
    
    public String ToString() {
        String carInfo = "color, " + color + "; fuel level(gallons), " + Double.toString(fuelLevel) + ";  mileage(miles), " + Double.toString(mileage) + "; mpg, " + 
                Double.toString(mpg) + "; max tank capacity(gallons), " + Double.toString(maxCapacity);
        return carInfo;
    }
        
}
