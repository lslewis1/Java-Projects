/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stopwatch;

/**
 *
 * @author Logan
 */
public class primeMethods {
   
// Methods to determine prime numbers

    public static boolean isPrime1(int x) {
        
            int rem=x%2;
            int div=3;
            while(div <x/2 && rem!=0) {
               div+=2;
               rem=x%div;
            }
             
            if(rem!=0) {
                return true;
            }
            
            else {
                return false;
            }
    }


    public static boolean isPrime2(int x) {

            int div=2;
            int c=0;
            while(div <x/2 ) {
            
              if(x%div ==0) {
                c+=1;
              }
              div+=1;
            }

            if(c==0) {
                return true;
            }
            
            else {
                return false;
            }
    }

}


