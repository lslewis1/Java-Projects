/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stopwatch;
import java.util.ArrayList;
/**
 *
 * @author Logan
 */
public class primeNumStopwatch {
    
    public static void main(String[] args) {
        
        Stopwatch sw1 = new Stopwatch();
        // Array list
        ArrayList<Integer> primes1 = new ArrayList<Integer>();
        
        sw1.start();
        for(int i = 1000; i < 10000; i++) {
            if (primeMethods.isPrime1(i)) {
                primes1.add(i);
            }
        }
        sw1.stop();
        
        System.out.println("It took " + sw1.getElapsedTime() + " milli seconds to create an Array List of all of the 4-digit prime numbers using the isPrime1 method");
        
        Stopwatch sw2 = new Stopwatch(); // a second stopwatch, created so that the elapsed times can be compared
        ArrayList<Integer> primes2 = new ArrayList<Integer>();
        
        sw2.start();
        for(int i = 1000; i < 10000; i++) {
            if (primeMethods.isPrime2(i)) {
                primes2.add(i);
            }
        }
        sw2.stop();
        
        System.out.println("It took " + sw2.getElapsedTime() + " milli seconds to create an Array List of all of the 4-digit prime numbers using the isPrime2 method");
        
        System.out.println();
        
        if (sw1.getElapsedTime() > sw2.getElapsedTime()) {
                System.out.println("Based on the results, the isPrime2 method is more efficient at counting the 4-digit prime numbers.");
        }
        else {
            System.out.println("Based on the results, the isPrime1 method is more efficient at counting the 4-digit prime numbers.");
        }
    }
}
