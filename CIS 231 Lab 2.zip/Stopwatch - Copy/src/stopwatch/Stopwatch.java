/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stopwatch;

/**
 *
 * @author Logan
 */
public class Stopwatch {
        
    private long startTime;
    private long endTime;
    private long elapsedTime;
        
    //System.currentTimeMillis(); long variable
    
    public Stopwatch() {
        
    }
    
    public void start() {
        startTime = System.currentTimeMillis();
        endTime = 0;
    }

    public void stop() {
        
        if (startTime == 0) {
            System.out.print("The stopwatch must be started first.");
        }
        else {
            endTime = System.currentTimeMillis();
        }

    }
    
    public long getElapsedTime() {
        
        elapsedTime = endTime - startTime;
        startTime = 0;
        endTime = 0;
        return elapsedTime;
        
    }

}
