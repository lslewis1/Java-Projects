/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mydoublelinkedlist;

import lab6.CarFX;
/**
 *
 * @author Logan
 */
public interface MyDoubleListInterface {

    void add(CarFX Car);
    void add(CarFX Car, int index) throws Exception;
    void remove(int index) throws Exception;
    int getSize();
    CarFX getHead();
    CarFX getTail();
    CarFX get(int Index) throws Exception;
    
}
