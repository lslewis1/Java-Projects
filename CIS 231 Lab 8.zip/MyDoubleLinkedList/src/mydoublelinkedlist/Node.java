/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mydoublelinkedlist;

import lab6.CarFX;

/**
 *
 * @author Logan
 */
public class Node {
    
    CarFX data;  // this is the data of a car object
    Node next;
    Node prev;
    public Node(CarFX Car)
    {
        data=Car;
        next=null;
        
    }
}
