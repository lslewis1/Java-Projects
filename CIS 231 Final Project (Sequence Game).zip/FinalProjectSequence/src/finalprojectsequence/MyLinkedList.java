/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalprojectsequence;

/**
 *
 * @author Logan
 */
public class MyLinkedList {
    
    int lSize = 0;
    Node head = null;
    Node current;
    
    public void add(Object O) {
        Node n = new Node(O);
        n.next = null;
        if(head == null) {
            head = n;
        }
        else {
            current = head;
            while(current.next != null) {
                current = current.next;
            }
            current.next = n;
        }
        lSize++;
    }
    
    
    public int getSize(){
        
        return lSize;
    }
    
    public Object get(int Index) throws Exception {
        if (Index < 0 || Index > lSize) {
           throw new Exception("out of bounds.");
        }
        else if (Index == 0) {
            return head.data;
        }
        else {
            current = head.next;
            int i = 1;
            while (i < Index) {
                current = current.next;
                i++;
            }
        }
        return current.data;
        
    }

}
