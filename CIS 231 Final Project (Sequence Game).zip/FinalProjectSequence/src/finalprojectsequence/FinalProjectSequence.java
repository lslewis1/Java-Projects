/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalprojectsequence;

import java.util.ArrayList;
import javafx.animation.FadeTransition;
import javafx.animation.SequentialTransition;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;

/**
 *
 * @author Logan
 */
public class FinalProjectSequence extends Application {
    
    // Global Variable list:
    
    Button Start, Restart, Green, Blue, Red, Next_Round, Exit;
    Text instructions;      // will contain the "instructions"
    Text end;               // will display when incorrect button is pressed
    Text scoreText;         // the score is displayed after an incorrect button is pressed, score goes up on each correct button press
    Text prevScore;         // displayed at the beginning, before game starts
    Text winText;           // displayed once the final round is reached
    Text correctText;       // text that is displayed when the player has completed a round, used to indicate that the next round button can be pressed
    
    // the global array list will be filled by reading a file with colors separated by a comma, these colors will then be used to create rectangles:
    
    ArrayList<String> Colors = new ArrayList<String>();   // Colors will be the list of colors on each line, which translates to each "round" of the game
    ArrayList<Rectangle> rects = new ArrayList();         // rectangles displayed on screen
    MyLinkedList Scores = new MyLinkedList();             // will be written to after the exit button is pressed, with latest score displayed before the game starts
    
    int pointer;  // used to reference the current location of a rectangle
    int score;    // incremented on each correct button press, used to determine the "round" (if equal to the size of the Colors array) - score for an individual round
    int tScore;     // total score that increments over the course of the entire gameplay
    int round;
    
   
    
    @Override
    public void start(Stage primaryStage) throws Exception {     // all rectangles generated will be the same size and location, only color and order shown will differ
        
        SequenceGameMethods SGM = new SequenceGameMethods();    // methods used throughout sequence game program are accessible through this instance variable
        
            Colors = SGM.readFile("SequenceFinalSquares.txt", 0);       // starts by adding the first line of colors, index 0 for the first line    
            rects = SGM.RectangleColors(Colors);                        // creates the rectangles, stores them in the global array list reference
            Scores = SGM.loadScores("ScoreFile.txt");                   // list of previous scores to be read from and written to.

        StackPane root = new StackPane();   //  will have the rectangles stacked in stack pane then added to center of border pane
        BorderPane bp = new BorderPane();   
        bp.setPadding(new Insets(40,20,20,20));     // Padding Syntax (importing java fx geometry insets)   left, top, bottom, right
        
        // displayed text messages: 
        
            Text instructions = new Text();
            instructions.setText("*CLICK THE BUTTONS IN THE ORDER THAT THE SQUARES APPEAR*");

            Text end = new Text();
            end.setText("Incorrect Button pressed - you lose.");    // will be placed in the center upon clicking the wrong button in the sequence

            Text scoreText = new Text();
            scoreText.setText("Round: " + round + "\n Score: " + tScore);

            Text prevScore = new Text();
            prevScore.setText("Previous score: " + Scores.get(Scores.getSize()-1));
        
        //
        
        // HBoxes :
         HBox hb = new HBox();   // HBox at the bottom of borderPane
        
            hb.setSpacing(15);      // sets spacing between each button
            hb.setPadding(new Insets(0,0,0,150));
        
         HBox hb2 = new HBox(); // displayed after user loses, only holds restart and exit buttons
            
            hb2.setSpacing(15);
            
        HBox hb3 = new HBox(); // only has next round button

        //
            
       // Button functionalities:    
        
            Button Start = new Button();            // Starts the game playing
            Start.setText("Start");
            Start.setOnAction(e-> {
                bp.setTop(instructions);
                
                if (round == 0) {

                   FadeTransition fade[] = new FadeTransition[rects.size()];       
                   SequentialTransition st = new SequentialTransition();
                   
                     for (int i = 0; i < rects.size(); i++) {    // fading animation, animates squares one after another using sequential fade tranisitons

                        fade[i] = new FadeTransition();
                        fade[i].setDuration(Duration.millis(1500)); 
                        fade[i].setNode(rects.get(i));
                        fade[i].setFromValue(1.0);
                        fade[i].setToValue(0);

                        st.getChildren().addAll(fade[i]);    
                    }
                    for (int j = rects.size()-1; j >= 0; j--) {     // displays in order of the list of rectangles
                        root.getChildren().add(rects.get(j));
                        bp.setBottom(null);
                    }

                    bp.setCenter(root); //  Squares will appear in the center
                    st.play();
                    
                    st.setOnFinished(g-> {  // sets hb at bottom of bp once the sequence transition finishes (EventHandler<ActionEvent> value)    
                        bp.setBottom(hb);
                    });    
                    
                    round++;        // increments the round, first round is round = 1
                    
                    scoreText.setText("Round: " + round + "\n Score: " + tScore);
                    bp.setRight(scoreText);

                }
                
                else {
                    return;
                }

            });

            Button Restart = new Button();            // Restarts the game using same functionality of start button, but global variables are reset
            Restart.setText("Restart");
            Restart.setOnAction(e-> {
                pointer = 0;
                round = 1;
                score = 0;
                tScore = 0;
                bp.setTop(instructions);
                bp.setBottom(null);
                scoreText.setText("Round: " + round + "\n Score: " + tScore);
                bp.setRight(scoreText);

                try {
                    Colors = SGM.readFile("SequenceFinalSquares.txt", 0);
                } catch (Exception ex) {}
                rects = SGM.RectangleColors(Colors); 


                FadeTransition fade[] = new FadeTransition[rects.size()];       
                SequentialTransition st = new SequentialTransition();

                  for (int i = 0; i < rects.size(); i++) {   

                     fade[i] = new FadeTransition();
                     fade[i].setDuration(Duration.millis(1500)); 
                     fade[i].setNode(rects.get(i));
                     fade[i].setFromValue(1.0);
                     fade[i].setToValue(0);

                     st.getChildren().addAll(fade[i]);    

                 }
                 for (int j = rects.size()-1; j >= 0; j--) {
                     root.getChildren().add(rects.get(j));
                 }

                 bp.setCenter(root); 
                 st.play();
                 
                 st.setOnFinished(g-> {  // sets hb at bottom of bp once the sequence transition finishes (EventHandler<ActionEvent> value)    
                        bp.setBottom(hb);
                }); 

            });

            Button Green = new Button();
            Green.setText("Green");
            Green.setOnAction(e-> {
                if (score == Colors.size()-1) {
                    Text correctText = new Text();
                    correctText.setText("Good job! Click Next Round.");
                    bp.setCenter(correctText);
                    bp.setBottom(hb3);
                }
                if (score == Colors.size()) {           // sets the next round button at the bottom when the round has been completed
                    bp.setBottom(hb3);
                }
                
                else if (Colors.get(pointer).equals("GREEN")) {
                    pointer++;
                    score++;
                    tScore++;
                    scoreText.setText("Round: " + round + "\n Score: " + tScore);
                    bp.setRight(scoreText);
                }
                else {       
                    bp.setCenter(end);
                    bp.setBottom(hb2);
                    bp.setRight(null);
                    scoreText.setText("Round: " + (round) + "\n Total Score: " + tScore);
                    bp.setTop(scoreText); 
                    Scores.add(tScore);
                    
                        try {
                            SGM.saveScores(Scores); // saves the scores into a file
                        } catch (Exception ex) {}
                }
            });

            Button Blue = new Button();
            Blue.setText("Blue");
            Blue.setOnAction(e-> {
                if (score == Colors.size()-1) {
                    Text correctText = new Text();
                    correctText.setText("Good job! Click Next Round.");
                    bp.setCenter(correctText);
                    bp.setBottom(hb3);
                }
                if (score == Colors.size()) {
                    bp.setBottom(hb3);
                }
                
                else if (Colors.get(pointer).equals("BLUE")) {
                    pointer++;
                    score++;
                    tScore++;
                    scoreText.setText("Round: " + round + "\n Score: " + tScore);
                    bp.setRight(scoreText);
                }
                else {       
                    bp.setCenter(end); 
                    bp.setBottom(hb2);
                    bp.setRight(null);
                    scoreText.setText("Round: " + (round) + "\n Total Score: " + tScore);
                    bp.setTop(scoreText); 
                    Scores.add(tScore);
                    
                        try {
                            SGM.saveScores(Scores); // saves the scores into a file
                        } catch (Exception ex) {}
                }
            });

            Button Red = new Button();
            Red.setText("Red");
            Red.setOnAction(e-> {
                if (score == Colors.size()-1) {
                    Text correctText = new Text();
                    correctText.setText("Good job! Click Next Round.");
                    bp.setCenter(correctText);
                    bp.setBottom(hb3);
                }
                if (score == Colors.size()) {
                    bp.setBottom(hb3);
                }

                else if (Colors.get(pointer).equals("RED")) {
                    pointer++;
                    score++;
                    tScore++;
                    scoreText.setText("Round: " + round + "\n Score: " + tScore);
                    bp.setRight(scoreText);
                }
                else {      
                    bp.setCenter(end);
                    bp.setBottom(hb2);
                    bp.setRight(null);
                    scoreText.setText("Round: " + (round) + "\n Total Score: " + tScore);
                    bp.setTop(scoreText);
                    Scores.add(tScore);
                    
                        try {
                            SGM.saveScores(Scores); // saves the scores into a file
                        } catch (Exception ex) {}
                }
            });

            Button Next_Round = new Button();       // displays the next round of squares, but only if the previous round was finished
            Next_Round.setText("Next Round");
            Next_Round.setOnAction(e-> {
                bp.setTop(instructions);
               
                pointer = 0;
                int d = 1510;
                if (round == 10) {
                    Text winText = new Text();
                    winText.setText("You win! All rounds completed with a final score of " + tScore);
                    bp.setCenter(winText);
                    Scores.add(tScore);
                    
                    try {
                            SGM.saveScores(Scores); // saves the scores into a file
                        } catch (Exception ex) {}
                    bp.setBottom(hb2);
                    
                    return;
                }
                else if (score == Colors.size()) {
                    bp.setBottom(null);
                    score = 0;
                    try {
                        Colors = SGM.readFile("SequenceFinalSquares.txt", round);
                    } catch (Exception ex) {}

                    rects = SGM.RectangleColors(Colors);

                    FadeTransition fade[] = new FadeTransition[rects.size()];
                    SequentialTransition st = new SequentialTransition();

                     for (int i = 0; i < rects.size(); i++) {    

                        fade[i] = new FadeTransition();
                        fade[i].setDuration(Duration.millis(d)); 
                        fade[i].setNode(rects.get(i));
                        fade[i].setFromValue(1.0);
                        fade[i].setToValue(0);
                        st.getChildren().add(fade[i]);    

                    }
                    for (int j = rects.size()-1; j >= 0; j--) {
                        root.getChildren().add(rects.get(j));
                    }

                    bp.setCenter(root); 
                    st.play();
                    
                    st.setOnFinished(g-> {  // sets hb at bottom of bp once the sequence transition finishes (EventHandler<ActionEvent> value)    
                        bp.setBottom(hb);
                    }); 
                    
                    round++;
                    
                    scoreText.setText("Round: " + round + "\n Score: " + tScore);
                    bp.setRight(scoreText);
                    d+=10;

                }

                else {
                    return;
                }
            });

            Button Exit = new Button();
            Exit.setText("Exit");
            Exit.setOnAction(e-> {  
                System.exit(0);
            });
        //
            
        // HBoxes:
            hb.getChildren().add(Green);
            hb.getChildren().add(Blue);
            hb.getChildren().add(Red);
            
            hb2.getChildren().add(Restart);    
            hb2.getChildren().add(Exit);
            
            hb3.getChildren().add(Next_Round);
        //
          
        // Border pane:     
        bp.setCenter(prevScore); 
        bp.setTop(instructions);
        bp.setBottom(Start);
        //
        
        Scene scene = new Scene(bp, 510, 510);
        
        primaryStage.setTitle("Sequence Game");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    
    /**
     * @param args the command line arguments
     */

    public static void main(String[] args) {
        launch(args);
    }
    
}
