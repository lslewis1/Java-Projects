/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalprojectsequence;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

/**
 *
 * @author Logan
 */
public class SequenceGameMethods {
    
    public static void main(String[] args) throws Exception {
     /* used to test functionality:
        
        ArrayList<String> colors = readFile("SequenceFinalSquares.txt",1);    
        ArrayList<Rectangle> list = RectangleColors(colors);
        MyLinkedList Scores = new MyLinkedList();
        Scores = loadScores("ScoreFile.txt");
        
     */
    }
    
    public ArrayList<String> readFile(String fileName, int LineNum) throws Exception {      // This method reads the specified file at the specified line 
                                                                                                // and returns a string array list
        
        ArrayList<String> LineColors = new ArrayList<String>();
        
        try {
            FileInputStream fis = new FileInputStream(new File(fileName));      // will use file name "SequenceFinalSquares.txt"

                BufferedReader br = new BufferedReader(new InputStreamReader(fis));
                String line = null; 

                for(int i = 0; i <= LineNum; i++) {  // goes over each line until the line needed (each line represents the current "round")
                   line = br.readLine();
                }
                
                //System.out.println(line); 

                String[] fields = line.split(",");

                // next line should add the colors from the current line to be used to create respective rectangles
                for (int i = 0; i < fields.length; i++) {
                    LineColors.add(fields[i]);
                }    

        } catch(Exception e) {e.printStackTrace();}     // catches any exceptions that the compiler discovers
        
        return LineColors;
    }
     
    public MyLinkedList loadScores(String fileName) {            // loads the previous scores from a file to be displayed as the GUI is started
        
        MyLinkedList ScoreList = new MyLinkedList();
        
        try {
            FileInputStream fis = new FileInputStream(new File(fileName));      // will use file name "SequenceFinalSquares.txt"

                BufferedReader br = new BufferedReader(new InputStreamReader(fis));
                String line = null; 
                
                line = br.readLine();
                //System.out.println(line);
                String[] fields = line.split(",");
                
                for (int i = 0; i < fields.length; i++) {
                    ScoreList.add(fields[i]);
                }                
                
        } catch(Exception e) {e.printStackTrace();} 
        
        return ScoreList;
    }
    
    
    public void saveScores(MyLinkedList ScoreList) throws Exception { // This method saves all the records in the ArrayList to a textfile, accesed when the user presses
                                                                                // an incorrect button and therefore loses, or when the user wins all rounds
        
        String fileName = "ScoreFile.txt";
        
        try {

            FileWriter fileWriter = new FileWriter(fileName);
            PrintWriter printWriter = new PrintWriter(fileWriter); 
            
            for (int i = 0; i < ScoreList.lSize; i++) {
                String record = ScoreList.get(i)+"";
                printWriter.print(record+",");
            }
            
            // Always close files.
            printWriter.close();
            fileWriter.close();
        }
        catch(IOException ex) {
            System.out.println("Error writing to file '" + fileName + "'");
            
        }
    }
     
    public ArrayList<Rectangle> RectangleColors(ArrayList<String> Colors) {     // Reads a list of colors and creates rectangles with those colors
        
         ArrayList<Rectangle> rects = new ArrayList();
         
          for (int i = 0; i < Colors.size(); i++) {       
            
            Rectangle Rect = new Rectangle(30,30,100,100);
            String rColor = Colors.get(i);
            
            switch (rColor) {
                
                case "BLUE":
                    Rect.setFill(Color.BLUE);
                    break;
            

                case "RED":
                    Rect.setFill(Color.RED);
                    break;
                
                case "GREEN":
                    Rect.setFill(Color.GREEN);
                    break;
                    
                    
            }
            rects.add(Rect);
        }
          return rects;
    }
    
}
