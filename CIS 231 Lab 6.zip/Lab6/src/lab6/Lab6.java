/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab6;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

/**
 *
 * @author Logan
 */
public class Lab6 extends Application {                     // Java Fx program that reads a file with text about a car to update information in a gui 
    
    Label Manufacturer, Model, Year, Price, Mileage, Days_On_Lot;
    TextField M, Mod, Y, P, Mil, DOL;
    Button Next, Previous, Insert, Delete, Exit;
    
    ArrayList<CarFX> CarArray = new ArrayList<CarFX>(); // Global ArrayList to be written to by main method and returned array from readFile method
    
    int Pointer;  // Global variable for location in an array (accessed by the buttons)
    
    ArrayList<CarFX> readFile(String fileName) {      // This method reads each line of the file
                                                            // Stores line info in a Car object and then stores the Car object in an ArrayList.
        ArrayList<CarFX> Cars = new ArrayList<CarFX>();
        
        
        try {
            FileInputStream fis = new FileInputStream(new File(fileName));
            
            // Construct Buffered Reader from InputStreamReader

                BufferedReader br = new BufferedReader(new InputStreamReader(fis));
                String line = null; 

                while ((line = br.readLine()) != null) {
                    System.out.println(line);
                    String[] fields = line.split(",");
                    // next line creates a new car object for each line read from file, with each attribute, and is added into the arrayList
                    Cars.add(new CarFX(fields[0], fields[1], fields[2], fields[3], fields[4], fields[5]));
                    
                
                }
                
        } catch(Exception e) {e.printStackTrace();}     // catches any exceptions that the compiler discovers
        
        return Cars;
    } 
    
    void saveFile(ArrayList<CarFX> updatedCars) { // This method saves all the records in the ArrayList to the original textfile, accesed by Exit button
        
        String fileName = "CarInfo.txt";
        Scanner scan = new Scanner(System.in);
        try {

            FileWriter fileWriter = new FileWriter(fileName);
            PrintWriter printWriter = new PrintWriter(fileWriter); // prints new lines, better than buffered writer
            
            for (int i = 0; i < updatedCars.size(); i++) {
                CarFX newCar = updatedCars.get(i);
                String record = newCar.Manufacturer + "," + newCar.Model + "," + newCar.Year + "," 
                                + newCar.Price + "," + newCar.Days_On_Lot + "," + newCar.Mileage;
                printWriter.println(record);
            }
            
            // Always close files.
            printWriter.close();
            fileWriter.close();
        }
        catch(IOException ex) {
            System.out.println("Error writing to file '" + fileName + "'");
            
        }
    }
    
    
    @Override
    public void start(Stage primaryStage) {     // Start method must call readFile before launching the application 
                                                // store the returned arraylist in a Global ArrayList reference.  
                                                // The start method will load the first object’s information in the GridPane 
                                                // To keep track of what record is currently being displayed we will use a "pointer" (global variable)
                                                // The pointer starts at zero and can go only up to the ArrayList size
                                                // The user must be able to navigate through all the records stored in the ArrayList
                                                // The user must also be able to delete and insert new records in the List (insert/delete buttons)

        Pointer = 0;
        CarArray = readFile("CarInfo.txt"); // the returned arrayList from the readFile method is stored in the global arrayList
        
        // The rest of the code deals with the layout of the GUI and button functionality
        Manufacturer = new Label("Manufacturer: ");
        Model = new Label("Model: ");
        Year = new Label("Year: ");
        Price = new Label("Price ($): ");
        Mileage = new Label("Mileage: ");
        Days_On_Lot = new Label("Days on lot: ");
        
        M = new TextField();
        Mod = new TextField();
        Y = new TextField();
        P = new TextField();
        Mil = new TextField();
        DOL = new TextField();
        
        
        // first car object's information is loeaded into the gridpane
        M.setText(CarArray.get(0).Manufacturer);
        Mod.setText(CarArray.get(0).Model);
        Y.setText(CarArray.get(0).Year);
        P.setText(CarArray.get(0).Price);
        Mil.setText(CarArray.get(0).Mileage);
        DOL.setText(CarArray.get(0).Days_On_Lot);  
        
        // Next and Previous button functionalities due 10/20
        
        Button Next = new Button();
        Next.setText("Next");
        Next.setOnAction(e-> {  // This button must increment the pointer
                                // retrieve the object from the pointer location from the ArrayList
                                // populate the textFields with Car’s data.
                                // If the pointer is at the Last record in the ArrayList then this button should be disabled.
            if (CarArray.size() == 0 || Pointer == (CarArray.size() - 1)) {
                return; // causes the button to be disabled, arrayList is at its last object, there is no next object in the list
            }
            
            else {
                Pointer++;
                M.setText(CarArray.get(Pointer).Manufacturer);
                Mod.setText(CarArray.get(Pointer).Model);
                Y.setText(CarArray.get(Pointer).Year);
                P.setText(CarArray.get(Pointer).Price);
                Mil.setText(CarArray.get(Pointer).Mileage);
                DOL.setText(CarArray.get(Pointer).Days_On_Lot);
            }
            
        });
        
        Button Previous = new Button();
        Previous.setText("Previous");
        Previous.setOnAction(e-> {  // This button must deccrement the pointer
                                    // retrieve the object from the pointer location from the ArrayList
                                    // populate the textFields with Cars’s data
                                    // If the pointer is at the first record in the ArrayList then this button should be disabled
            if (CarArray.size() == 0 || Pointer == 0) {
                return; // causes the button to be disabled, arrayList is at its first object, there is no previous object in the list
            }
            
            else {
                Pointer--;
                M.setText(CarArray.get(Pointer).Manufacturer);
                Mod.setText(CarArray.get(Pointer).Model);
                Y.setText(CarArray.get(Pointer).Year);
                P.setText(CarArray.get(Pointer).Price);
                Mil.setText(CarArray.get(Pointer).Mileage);
                DOL.setText(CarArray.get(Pointer).Days_On_Lot);
            }
            
        });
        
        Button Insert = new Button();      
        Insert.setText("Insert");
        Insert.setOnAction(e-> {  // This must read the data from the textfields, create a Car object, and store the object at the pointer location.
            CarFX insertCar = new CarFX();
            
            if (Pointer == (CarArray.size() -1)) {
                insertCar.Manufacturer = M.getText();
                insertCar.Model = Mod.getText();
                insertCar.Year = Y.getText();
                insertCar.Price = P.getText();
                insertCar.Mileage = Mil.getText();
                insertCar.Days_On_Lot = DOL.getText();

                CarArray.add(insertCar); 
                Pointer++;
            }
            
            else {
                insertCar.Manufacturer = M.getText();
                insertCar.Model = Mod.getText();
                insertCar.Year = Y.getText();
                insertCar.Price = P.getText();
                insertCar.Mileage = Mil.getText();
                insertCar.Days_On_Lot = DOL.getText();

                CarArray.add(Pointer, insertCar);    // added at the pointer location, the object currently at this location moves up one spot
            }

        });
        
        Button Delete = new Button();  
        Delete.setText("Delete");
        Delete.setOnAction(e-> {  // This button must delete the object at the pointer location and display the next object data in the text fields.
            
            if (CarArray.size() == 0) {
                return;     // delete button is disabled if there are no objects to delete
            }
                    
            else if (CarArray.size() == 1 && Pointer == 0) { // last remaining object in the list is deleted, should display blank fields
                CarArray.remove(Pointer);
                M.setText("");
                Mod.setText("");
                Y.setText("");
                P.setText("");
                Mil.setText("");
                DOL.setText("");
                return;
            } // Nissan,Sentra,2012,11500,48900,21 
            
            else if (Pointer == (CarArray.size() - 1)) {    // final object is removed and the previous object's data is displayed
                CarArray.remove(Pointer);
                M.setText(CarArray.get(Pointer-1).Manufacturer);
                Mod.setText(CarArray.get(Pointer-1).Model);
                Y.setText(CarArray.get(Pointer-1).Year);
                P.setText(CarArray.get(Pointer-1).Price);
                Mil.setText(CarArray.get(Pointer-1).Mileage);
                DOL.setText(CarArray.get(Pointer-1).Days_On_Lot);
                Pointer--;
            }
            
            else {      // otherwise the next object is displayed
                CarArray.remove(Pointer);
                M.setText(CarArray.get(Pointer).Manufacturer);
                Mod.setText(CarArray.get(Pointer).Model);
                Y.setText(CarArray.get(Pointer).Year);
                P.setText(CarArray.get(Pointer).Price);
                Mil.setText(CarArray.get(Pointer).Mileage);
                DOL.setText(CarArray.get(Pointer).Days_On_Lot);
            }
        });
        
        Button Exit = new Button();
        Exit.setText("Exit");
        Exit.setOnAction(e-> {  // This button must call the saveFile function
                                // It must read each object in the ArrayList
                                // Prepare a string and write that String in the file.
            saveFile(CarArray);
            System.exit(0);
        });

        GridPane root = new GridPane(); // Gridpane in center of borderPane
        
            root.setHgap(10); // horizontal gap in pixels
            root.setVgap(10); // vertical gap in pixels
            root.setPadding(new Insets(0,0,15,0)); // left, right, bottom, top
        
            root.add(Manufacturer,0,0);
            root.add(M,1,0);

            root.add(Model,0,1);
            root.add(Mod,1,1);
            
            root.add(Year,0,2);
            root.add(Y,1,2);
            
            root.add(Price,0,3);
            root.add(P,1,3);
            
            root.add(Mileage,0,4);
            root.add(Mil,1,4);
            
            root.add(Days_On_Lot,0,5);
            root.add(DOL,1,5);
        
        
        HBox hb = new HBox();   // HBox at the bottom of borderPane
        
            hb.setSpacing(7);      // sets spacing between each button
            
        
            hb.getChildren().add(Next);
            hb.getChildren().add(Previous);
            hb.getChildren().add(Insert);
            hb.getChildren().add(Delete);
            hb.getChildren().add(Exit);
            
        BorderPane bp = new BorderPane();   
            bp.setPadding(new Insets(10,20,10,20));     // Padding Syntax (importing java fx geometry insets)
            bp.setCenter(root);
            bp.setBottom(hb);
        
        Scene scene = new Scene(bp, 310, 255);
        
        primaryStage.setTitle("Car Information");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
