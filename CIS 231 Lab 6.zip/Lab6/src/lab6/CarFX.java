/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab6;

/**
 *
 * @author Logan
 */
public class CarFX {    // objects used for the arrayList in Lab6 GUI
    
    public String Manufacturer;  
    public String Model;
    public String Year; 
    public String Price;
    public String Mileage;
    public String Days_On_Lot;
    
    
    public CarFX(String newMan, String newModel, String newYear, String newPrice, String newMil, String Days) { // Constructor takes class name, creates new CarFX with specified attributes.
        
        Manufacturer = newMan;
        Model = newModel;
        Year = newYear;
        Price = newPrice;
        Mileage = newMil;
        Days_On_Lot = Days;
        
    }
    
    public CarFX() {  // default constructor
        
    }
}
