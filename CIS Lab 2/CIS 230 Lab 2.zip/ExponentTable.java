public class ExponentTable {

   public static void main (String [] args) {

   int a=1, b=2;

   System.out.println("a     b   pow(a, b)");

   System.out.print(a+"     ");

   System.out.print(b+"      ");

   System.out.println(Math.pow(a, b));

   a=2;
   b=3;

   System.out.print(a+"     ");

   System.out.print(b+"      ");

   System.out.println(Math.pow(a, b));

   a=3;
   b=4;

   System.out.print(a+"     ");

   System.out.print(b+"      ");

   System.out.println(Math.pow(a, b));

   a=4;
   b=5;

   System.out.print(a+"     ");

   System.out.print(b+"      ");

   System.out.println(Math.pow(a, b));

   a=5;
   b=6;

   System.out.print(a+"     ");

      System.out.print(b+"      ");

   System.out.println(Math.pow(a, b));




   return;

  }

}