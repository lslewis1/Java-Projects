/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package carlinkedlist;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import lab6.CarFX;
import mylinkedlist.Node;
import mylinkedlist.MyLinkedList;

/**
 *
 * @author Logan
 */
public class CarLinkedList {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        new CarLinkedList();
        
    }
    
    CarLinkedList() throws Exception {               // use linked list in place of the array list for the read file method
                                    // load data from the CarInfo.txt file of Car Objects, Save the Objects as Nodes  and add the Nodes to the LinkedList.
                                    // load cars into Linkedlist, display information using a for loop.
        MyLinkedList CarList = readFile("CarInfo.txt");
        int Size = CarList.getSize();
        
        for(int i = 0; i < Size; i++) {
            System.out.println(CarList.get(i).Manufacturer + ", " + CarList.get(i).Model + ", " + CarList.get(i).Year +
                           ", " + CarList.get(i).Price + ", " + CarList.get(i).Mileage + ", " + CarList.get(i).Days_On_Lot);
        }
    }
    
    public MyLinkedList readFile(String fileName) {      // This method reads each line of the file
                                                            // Stores line info in a Car object and then stores the Car object in an Node.
        
        MyLinkedList Cars = new MyLinkedList();
        CarFX car = new CarFX();
        
        
        try {
            FileInputStream fis = new FileInputStream(new File(fileName));
            
            // Construct Buffered Reader from InputStreamReader

                BufferedReader br = new BufferedReader(new InputStreamReader(fis));
                String line = null; 

                while ((line = br.readLine()) != null) {
                    String[] fields = line.split(",");
                    car = new CarFX(fields[0],fields[1],fields[2],fields[3],fields[4],fields[5]);
                    Cars.add(car);                
                }
                
        } catch(Exception e) {e.printStackTrace();}     // catches any exceptions that the compiler discovers
        
        return Cars;        // returns the linked list of cars
    } 
    
}
