/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mylinkedlist;

import lab6.CarFX;
/**
 *
 * @author Logan
 */
public class MyLinkedList implements MyLinkedListInterface{

    int lSize = 0;
    Node head = null;
    Node tail = null;   // tail is the last node in the linked list
    Node current;
    
    public static void main(String[] args) {
        new MyLinkedList();
    }
    
    public MyLinkedList() {   // used to test the functionality of the linkedlist
       /*CarFX Car = new CarFX("1","1","1","1","1","1");
        add(Car);
        Car = getHead();
        
        System.out.println(Car.Manufacturer + ", " + Car.Model + ", " + Car.Year +
                           ", " + Car.Price + ", " + Car.Mileage + ", " + Car.Days_On_Lot);
        
        CarFX Car2 = new CarFX("2","2","2","2","2","2");
        add(Car2);
        
        System.out.println(getTail().Days_On_Lot);
        
        System.out.println(getSize());
       */
    }
  
    
    public void add(CarFX Car) {
        Node n = new Node(Car);
        n.next = null;
        if(head == null) {
            head = n;
        }
        else {
            current = head;
            while(current.next != null) {
                current = current.next;
            }
            current.next = n;
        }
        lSize++;
    }
    
    
    public void add(CarFX Car, int index) throws Exception {
        if (index < 0 || index > lSize) {
            throw new Exception("out of bounds.");
        }
        else if (index == 0) {
            Node n = new Node(Car);
            n.next = head;
            lSize++;
            head = n;
        }
        else {
            Node n = new Node(Car);
            current = head;
            int i = 1;
            while (i < index) {
                current = current.next;
                i++;
            }
            Node tmp = current.next;
            current.next = n;
            n.next = tmp;
            lSize++;
        }
     }
    
    
   
    public void remove(int index) throws Exception {
        if (index < 0 || index >= lSize) {
            throw new Exception ("Index out of bounds.");
        }
        else if (index==0) {
            head = head.next;
            lSize--;
        }
        else {
            current = head;
            int i = 1;
            while (i < index) {
                current = current.next;
                i++;
            }
            Node tmp = current.next;
            current.next = tmp.next;
            lSize--;
        }
     }
    
    public int getSize(){
        
        return lSize;
    }
    
    public CarFX getHead() {
        if (lSize == 0) {
            return null;
        }
        else {
            return head.data;
        }
    }
    
    public CarFX getTail() {
        if (lSize == 1) {
            tail = head;
        }
        else {
            while (current.next!=null) {
                current = current.next;
            }
            tail = current; // the next node reference is null, therefore this is the last node in the linked list
        }
        return tail.data;
    }
    
   
    @Override
    public CarFX get(int Index) throws Exception {
        if (Index < 0 || Index > lSize) {
           throw new Exception("out of bounds.");
        }
        else if (Index == 0) {
            return head.data;
        }
        else {
            current = head.next;
            int i = 1;
            while (i < Index) {
                current = current.next;
                i++;
            }
        }
        return current.data;
        
    }
    
    
    
    
}
