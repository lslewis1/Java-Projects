/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conversion;

/**
 *
 * @author Logan
 */
public interface Conversion {
    
    String toHex(String num);   // hexadecimal, base 6
    String toOct(String num);   // octal, base 8
    String toBin(String num);   // binary, base 2
}
