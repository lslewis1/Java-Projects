/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conversion;

import java.io.*;
import java.util.ArrayList;
/**
 *
 * @author Logan
 */
public class ConversionApp {    // this class reads and writes to files
    
    public static void main(String[] args) {
        new ConversionApp();        // executes the instructions from the constructor below
    }
    
    public ConversionApp() {    // will use DEC.toHex() for example
        ArrayList<String> Conversions = readFile("Integers.txt");       // Integers.txt is the text file with integers to be converted, it is located in the Conversion project folder
        writeFile(Conversions, "Conversionfile.txt");       // Conversionfile.txt is the text file that is written to with the converted values, located in Conversion project folder
    }
        // this is the segment that reads the file
    
    public ArrayList<String> readFile(String fileName) {

        ArrayList<String> convList = new ArrayList<>();
        
        DEC DecConv = new DEC();    // have to declare DEC object to use the non-static mehtods that override the conversion interface

        String line = null;

        try {
            FileReader fileReader = new FileReader(fileName);
            BufferedReader bufferedReader =  new BufferedReader(fileReader);

            while((line = bufferedReader.readLine()) != null) {
                
                String integer = line;
                convList.add(integer);
                convList.add(DecConv.toBin(integer));
                convList.add(DecConv.toOct(integer));
                convList.add(DecConv.toHex(integer));
   
                       
            }
            bufferedReader.close();
            fileReader.close();
        }
        catch(FileNotFoundException ex) {
            System.out.println( "File not found '" + fileName + "'");
        }
        catch(IOException ex) {
            System.out.println("Cannot open File '" + fileName + "'");

        }
        return convList;
        // end of reading file
    }
    
    public void writeFile(ArrayList<String> convList,String fileName) {
        // now writes to a new file location in the format: integer, binary,  octal, hexadecimal
        
       
        try {

            FileWriter fileWriter = new FileWriter(fileName);
            PrintWriter printWriter = new PrintWriter(fileWriter); // prints new lines, better than buffered writer
            String Conversions = "";
            for (int i = 0; i < convList.size(); i+= 4) {
                Conversions = "";
                Conversions += convList.get(i);
                
                for (int j = i + 1; j < i + 4; j++) {
                    Conversions += ", " + convList.get(j);
                }
                
                printWriter.println(Conversions);
            }
            
            // Always close files.
            printWriter.close();
            fileWriter.close();
        }
        catch(IOException ex) {
            System.out.println("Error writing to file '" + fileName + "'");
            
        }
    }
   
}
