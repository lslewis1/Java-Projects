/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conversion;

/**
 *
 * @author Logan
 */
public class DEC implements Conversion {    // this class implements the conversion interface, overriding the methods, and accounts for possible thrown exceptions
     
    public String toHex(String num) {
        String hexNum = "";
        
         try {
        
            int intVal = Integer.parseInt(num); // this is where exception may be thrown
            int remainder;
        
            char[] hexDigits ={'0','1','2','3','4','5','6','7','8','9',
                            'A','B','C','D','E','F'};
 
            while(intVal > 0) {
                
            remainder = intVal % 16; 
            hexNum = hexDigits[remainder] + hexNum; 
            intVal = intVal / 16; // integer division
            
            }
         }
       
        
        catch (NumberFormatException nfe) {     //exception caught if the given string value cannot be represented as an integer
            System.out.println("The string entered cannot be represented as an integer value.");
        }
       
        return hexNum;
    }
    
    public String toOct(String num) {
       String octNum = "";
        
        try {
            
            int intVal = Integer.parseInt(num);
            int remainder;

            char octDigits[]={'0','1','2','3','4','5','6','7'};

            while(intVal > 0) {

                remainder = intVal % 8;
                octNum = octDigits[remainder] + octNum;
                intVal = intVal / 8; // integer division
            }
        }
       catch(NumberFormatException nfe) {
           System.out.println("The string entered cannot be represented as an integer value.");
       }
        ;
        return octNum;
    }
    
    public String toBin(String num) {    // print this number backwards
       
            String binNum = "";
        try {
            int intVal = Integer.parseInt(num);
            int remainder;

            char binDigits[] = {'0','1'};

            while(intVal > 0) {

                remainder = intVal % 2;
                binNum = binDigits[remainder] + binNum;
                intVal = intVal / 2;
            }
        }
        catch(NumberFormatException nfe) {
           System.out.println("The string entered cannot be represented as an integer value.");
       }
        
        return binNum;
    }
}
