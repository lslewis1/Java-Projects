/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stack;

import java.util.Vector;

/**
 *
 * @author Logan
 */
public class MyStack {
 
    private Vector vectorStack = new Vector();  // implement as a vector
    
    public void push(Object O) {
        vectorStack.addElement(O);
    }
    
    public void pop() throws Exception {
        if (vectorStack.isEmpty()) {
            throw new Exception("Out of bounds");
        }
        else {
            vectorStack.remove((vectorStack.size()-1));
        }
    }
    
    public Object peek() throws Exception {  // checks the value of the top object in the stack, without removing it
        if (vectorStack.isEmpty()) {
            return null;
        }
        else {
            return vectorStack.get(vectorStack.size()-1);
        }
    }
    
    public int Size() {        
        return vectorStack.size();
    }
    
    public boolean isEmpty() {
        return vectorStack.isEmpty();
    }
}
