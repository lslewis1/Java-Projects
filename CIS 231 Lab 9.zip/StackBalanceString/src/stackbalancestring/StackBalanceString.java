/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stackbalancestring;
import java.util.Scanner;
import stack.MyStack;
/**
 *
 * @author Logan
 */
public class StackBalanceString {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {    // use a vector (java has a vector class)
        new StackBalanceString();
    }
    
    Scanner scan = new Scanner (System.in);
    String testString = "";
    boolean BALANCED = true;
    
    public StackBalanceString() throws Exception {
        
       MyStack Stack = new MyStack();
       System.out.println("Enter a string of brackets, open and closed, to see if it is balanced");
       String mS = scan.next();
       char[] tmp = mS.toCharArray();
       
       for (int i = 0; i < tmp.length; i++) {
            switch (tmp[i]) {
                    
                case '(':
                case '[':
                case'{':
                       Stack.push(tmp[i]); 
                       break;
    
                case ')':
                       tmp[i] = '(';
                       testString = Stack.peek() + ""; 
                       if (Stack.isEmpty()) {
                           BALANCED = false;
                           break;
                       }
                       else if (testString.equals(tmp[i] + "")) {
                           Stack.pop();
                       }
                       
                       else {
                            break;
                       }
                       break;
                       
                case '}':
                       tmp[i] = '{';
                       testString = Stack.peek() + "";
                       if (Stack.isEmpty()) {
                           BALANCED = false;
                           break;
                       }
                       else if (testString.equals(tmp[i] + "")) {
                           Stack.pop();
                       }
                       
                       else {
                            break;
                       }
                       break;
                    
                case ']':
                       tmp[i] = '[';
                       testString = Stack.peek() + ""; 
                       if (Stack.isEmpty()) {
                           BALANCED = false;
                           break;
                       }
                       else if (testString.equals(tmp[i] + "")) {
                           Stack.pop();
                       }
                       
                       else {
                            break;
                       }
                       break;
            }

        } 
                
       if (!BALANCED) {
           System.out.println("The string " + mS + " is not balanced.");
       }
       else if (Stack.isEmpty()) {
           System.out.println("The string " + mS + " is balanced.");
       }
       else {
           System.out.println("The string " + mS + " is not balanced.");
       }
       
    }
    
    
    
}
