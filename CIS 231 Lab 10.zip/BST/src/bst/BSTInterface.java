/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bst;

/**
 *
 * @author Logan
 */
public interface BSTInterface {
    
  public void add(Person pr)  ;
  public Person find(int key) ;
  public void LNR(Node root)  ; // left node right
  public void LRN(Node root)  ; // left right node
  public void NLR(Node root)   ; // node left right
}
