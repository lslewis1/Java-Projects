/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bst;

/**
 *
 * @author Logan
 */
public class Person
{   
   public String name; 
   public int id;      // acts as the key for a search   
   public Person(String newName,int newID)
      {     
        name=newName;       
        id=newID;    }   
       public int getID()   
         {       
             return id;   
          }
}

