/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bst;

/**
 *
 * @author Logan
 */
public class BST implements BSTInterface {

    public Node root = null;
    public Node current;
    public int treeSize = 0;
    public Node tmp;
    
    public void add(Person pr) {
        
        Node n = new Node(pr);
        if (root == null) {
            root = n;
            treeSize++;
        }
        else {
            current = root;
            while (current!= null) {
                tmp = current;
                if (n.key > current.key) {
                    current =  current.rightChild;
                }
                else {
                    current = current.leftChild;
                }
            }
            if (n.key > tmp.key) {
                tmp.rightChild = n;
            }
            else {
                tmp.leftChild = n;
            }
            treeSize++;
        }
    }
    
    public Person find(int key) {
        
        Person response = null;
        current = root;
        boolean done = false;  // flag to stop recursion
        
        while (!done && current != null) {
            if (current.key < key) {
                current = current.rightChild;
            }
            else if (current.key > key) {
                current = current.leftChild;
            }
            else { // keys are equal
                done = true;
                response = current.node;        // node acts as teh "data" in this case a person object
            }
        }
        return response;
    }
    
    public void LNR(Node root) {    // in - order
        
        if (root != null) {
            LNR(root.leftChild);
            System.out.print(root.node.name + " ");
            LNR(root.rightChild);
        }
    }
    
    public void LRN(Node root) {    // post - order 
        
         if (root != null) {
            LRN(root.leftChild);
            LRN(root.rightChild);
            System.out.print(root.node.name + " ");
         }
    }
    
    public void NLR(Node root) {    // pre - order
        
        if (root != null) {
            System.out.print(root.node.name + " ");
            LRN(root.leftChild);
            LRN(root.rightChild);
         }
    }
    
}
