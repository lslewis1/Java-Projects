/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bst;

/**
 *
 * @author Logan
 */
public class Node<Object>
{   
   public Person node;
   Node<Object> leftChild=null; 
   Node<Object> rightChild=null; 
   int key=0;   
   public Node (Person obj)   
   {       
     key=obj.id;     
     node=obj; 
    }   
  }

