/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bst_tester;

import bst.BST;
import bst.Person;
import java.util.Scanner;
import bst.Node;
/**
 *
 * @author Logan
 */
public class BST_Tester {
    Scanner scan = new Scanner(System.in);  
    BST myTree = new BST();
    public static void main(String[] args) {
        
        new BST_Tester();
        
    }
    public BST_Tester() {

            buildTree(myTree);
            
            System.out.println();
            System.out.println("The tree traversal in the in-order method is: ");
            myTree.LNR(myTree.root);
            
            System.out.println();
            System.out.println("The tree traversal in the post-order method is: "); 
            myTree.LRN(myTree.root);
            
            System.out.println();
            System.out.println("The tree traversal in the pre-order method is: ");
            myTree.NLR(myTree.root);
            
            System.out.println();
            
        }
    
    void buildTree(BST tree) {
        
        String userInput = "YES";
        
        while (userInput.equalsIgnoreCase("YES")) {
            
            System.out.println("Enter the id of the person: ");
            int id = scan.nextInt();
           
            if(tree.find(id)!= null) {
                System.out.println("Error - a person with this id is already in the tree.");
            }
            
            else { 
                
                System.out.println("Enter the person's name: ");
                String name = scan.next();
                
                Person p1 = new Person(name, id);
                tree.add(p1);
            }

            System.out.println("Would you like to continue? (yes or no) ");
            userInput = scan.next();
        }
    }

    
}
