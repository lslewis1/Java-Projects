/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package recursion;

import java.util.Scanner;

/**
 *
 * @author Logan
 */
public class NumberGuess {
    
    public static void main(String[] args) {
        
        new NumberGuess();
    }
    
    public NumberGuess() {
        
        System.out.println("Think of a number between 1 and 100");
        
        numGuess(1,100);
        
    }
    
    public void numGuess(int start, int end) {     // 1. guess higher, 2. guess lower, 3. correct
        Scanner scan = new Scanner(System.in);
        int userChoice = 0;
        
        int guess = (start + end) / 2;      
        System.out.println("My guess is " + guess);
        System.out.println("Please choose \n 1. for a higher guess  \n 2. for a lower guess  \n 3. if the guess was correct \n choice:  ");
        userChoice = scan.nextInt();

        if (userChoice == 3){ 
            System.out.println("The number you were thinking of was " + guess + "!");
            return;
        }
        
        if (guess == end-1) {     // must have a base case to see if the user is cheating
            System.out.println("Your number was " + guess + ", You are cheating!");
            return;
        }
       
        else if (userChoice == 2) { 
            System.out.println("Guessing lower...");
            numGuess(start, guess);  // recursive call for  if the guess must be lower
        }
        
        else if (userChoice == 1) {
            System.out.println("Guessing higher...");
            numGuess(guess, end);   // recursive call for if the guess must be higher
        }
        
        else {
            System.out.println("Incorrect choice, must be a 1., 2., or, a 3.");
            return;
        }
     }
}

