/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geometricobject;

/**
 *
 * @author Logan
 */
public class CylinderObject extends GeometricObject {
    private double radius;
    private double height;
    
    public CylinderObject(double newRadius, double newHeight) {
        radius = newRadius;
        height = newHeight;
    }
    
    double area() {
        double circumference = (2 * Math.PI) * radius;
        return (circumference * height) + ((2 * Math.PI) * (radius * radius));
    }
    
    double getPerimeter() {
        return -1;
    }
    
    double getVolume() {
        return (Math.PI * radius * radius * height);
    }
}
