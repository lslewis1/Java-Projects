/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geometricobject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

/**
 *
 * @author Logan
 */
public class GeometricObjectApp{ // uses Array List instead of arrays, a UML diagram for the class hierarchy is stored in the project folder, along with the Data.dat file that is read from
    public static void main(String[] args) {
        new GeometricObjectApp();
    }

    public GeometricObjectApp() {
        ArrayList<GeometricObject> myObj = new ArrayList<GeometricObject>();
        myObj = readFile("Data.dat");
        printObjects(myObj);
    }



    public void printObjects(ArrayList<GeometricObject> GoArr) {
        System.out.println();
        
        for(int i = 0; i < GoArr.size(); i++) {
            if(GoArr.get(i).ThreeD) {
                System.out.println("Object " + (i+1) + " is a " + GoArr.get(i).name + "\n  its area is: " + GoArr.get(i).area() + " square units" +
                                "\n  This object is three-dimensional and therefore does not have perimeter.\n  its volume is: " + GoArr.get(i).getVolume() + " cubed units. \n");
            }
            else {
                System.out.println("Object " + (i+1) + " is a " + GoArr.get(i).name + "\n  its area is: " + GoArr.get(i).area() + " square units" +
                                "\n  its perimeter is: " + GoArr.get(i).getPerimeter() + " units" + "\n  This object is two-dimensional and therefore does not have volume. \n");
            }
        }
    }

    private ArrayList<GeometricObject> readFile(String name) {
        ArrayList<GeometricObject> Go = new ArrayList<GeometricObject>();
        int count = 0;
        try {
            FileInputStream fis = new FileInputStream(new File(name));
            System.out.println("File opened");
            // Construct Buffered Reader from InputStreamReader

                BufferedReader br = new BufferedReader(new InputStreamReader(fis));
                String line = null; 

                while ((line = br.readLine()) != null) {
                    System.out.println(line);
                    String[] fields = line.split(",");
                    int type = Integer.parseInt(fields[0]);
                    switch(type) {

                        case 1:
                        Go.add(new RectangleObject(Double.parseDouble(fields[1]), Double.parseDouble(fields[2])));
                        Go.get(count).name = "Rectangle";
                        Go.get(count).ThreeD = false;       // shows that the rectangle is not three dimensional
                        count++;
                        break;

                        case 2:
                        Go.add(new CircleObject(Double.parseDouble(fields[1])));
                        Go.get(count).name = "Circle";
                        Go.get(count).ThreeD = false;
                        count++;
                        break;

                        case 3:
                        Go.add(new SquareObject(Double.parseDouble(fields[1])));
                        Go.get(count).name = "Square";
                        Go.get(count).ThreeD = false;
                        count++;
                        break;

                        case 4:
                        Go.add(new CylinderObject(Double.parseDouble(fields[1]), Double.parseDouble(fields[2])));
                        Go.get(count).name = "Cylinder";
                        Go.get(count).ThreeD = true;
                        count++;
                        break;

                        case 5:
                        Go.add(new SphereObject(Double.parseDouble(fields[1])));
                        Go.get(count).name = "Sphere";
                        Go.get(count).ThreeD = true;
                        count++;
                        break;
                            
                        case 6:
                        Go.add(new RightTriangle(Double.parseDouble(fields[1]), Double.parseDouble(fields[2]), Double.parseDouble(fields[2])));
                        Go.get(count).name = "Right Triangle";
                        Go.get(count).ThreeD = false;
                        count++;
                        break;

                    }

                }
        } catch(Exception e) {e.printStackTrace();}     // catches any exceptions that the compiler discovers
    return Go;
    } 
}

/* original code (arrays)

package geometricobject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;


public class GeometricObjectApp{ // need to use Array List instead of arrays, and create a UML diagram for the class hierarchy, store in the project folder
    public static void main(String[] args) {
        new GeometricObjectApp();
    }

    public GeometricObjectApp() {
        GeometricObject[] myObj = readFile("Data.dat");
        printObjects(myObj);
    }



    public void printObjects(GeometricObject[] GoArr) {
        System.out.println();
        
        for(int i = 0; i < GoArr.length; i++) {
            if(GoArr[i].ThreeD) {
                System.out.println("Object " + (i+1) + " is a " + GoArr[i].name + "\n  its area is: " + GoArr[i].area() + " square units" +
                                "\n  This object is three-dimensional and therefore does not have perimeter.\n  its volume is: " + GoArr[i].getVolume() + " cubed units. \n");
            }
            else {
                System.out.println("Object " + (i+1) + " is a " + GoArr[i].name + "\n  its area is: " + GoArr[i].area() + " square units" +
                                "\n  its perimeter is: " + GoArr[i].getPerimeter() + " units" + "\n  This object is two-dimensional and therefore does not have volume. \n");
            }
        }
    }

    private GeometricObject[] readFile(String name) {
        GeometricObject[] Go = new GeometricObject[6];
        int count = 0;
        try {
            FileInputStream fis = new FileInputStream(new File(name));
            System.out.println("File opened");
            // Construct Buffered Reader from InputStreamReader

                BufferedReader br = new BufferedReader(new InputStreamReader(fis));
                String line = null; 

                while ((line = br.readLine()) != null) {
                    System.out.println(line);
                    String[] fields = line.split(",");
                    int type = Integer.parseInt(fields[0]);
                    switch(type) {

                        case 1:
                        Go[count] = new RectangleObject(Double.parseDouble(fields[1]), Double.parseDouble(fields[2]));
                        Go[count].name = "Rectangle";
                        Go[count].ThreeD = false;       // shows that the rectangle is not three dimensional
                        count++;
                        break;

                        case 2:
                        Go[count] = new CircleObject(Double.parseDouble(fields[1]));
                        Go[count].name = "Circle";
                        Go[count].ThreeD = false;
                        count++;
                        break;

                        case 3:
                        Go[count] = new SquareObject(Double.parseDouble(fields[1]));
                        Go[count].name = "Square";
                        Go[count].ThreeD = false;
                        count++;
                        break;

                        case 4:
                        Go[count] = new CylinderObject(Double.parseDouble(fields[1]), Double.parseDouble(fields[2]));
                        Go[count].name = "Cylinder";
                        Go[count].ThreeD = true;
                        count++;
                        break;

                        case 5:
                        Go[count] = new SphereObject(Double.parseDouble(fields[1]));
                        Go[count].name = "Sphere";
                        Go[count].ThreeD = true;
                        count++;
                        break;
                            
                        case 6:
                        Go[count] = new RightTriangle(Double.parseDouble(fields[1]), Double.parseDouble(fields[2]), Double.parseDouble(fields[2]));
                        Go[count].name = "Right Triangle";
                        Go[count].ThreeD = false;
                        count++;
                        break;

                    }

                }
        } catch(Exception e) {e.printStackTrace();}     // catches any exceptions that the compiler discovers
    return Go;
    } 
}
*/

