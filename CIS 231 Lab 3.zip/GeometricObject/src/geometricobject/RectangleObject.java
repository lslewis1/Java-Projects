/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geometricobject;

/**
 *
 * @author Logan
 */
class RectangleObject extends GeometricObject {
    private double length;
    private double width;
    
    public RectangleObject(double newLength, double newWidth) {
        length = newLength;
        width = newWidth;
    }
    double area() {
        return (length * width);
    }
    
    double getPerimeter() {
        return ((2 * length) +  (2 * width)); 
    }
    
    double getVolume() {
        return -1;
    }
} 