/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geometricobject;

/**
 *
 * @author Logan
 */

class SquareObject extends GeometricObject {
    private double length;
    
    public SquareObject(double newLength) {
        length = newLength;
    }
    double area() {
        double area = (length * length);
        return area;
    }
    
    double getPerimeter() {
        return 4 * length;
    }
    
    double getVolume() {
        return -1;
    }
}
