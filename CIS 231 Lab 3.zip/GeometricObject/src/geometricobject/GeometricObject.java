/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geometricobject;

/**
 *
 * @author Logan
 */

public abstract class GeometricObject {     // keep variables private within the classes

    String name;
    Boolean ThreeD; // defines whether an object is 2D or 3D (true is 3D, false is 2D)
    
    abstract double area();
    abstract double getPerimeter();     // returns -1 for 3D objects
    abstract double getVolume();        // returns -1 for 2D objects
    
}

