/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geometricobject;

/**
 *
 * @author Logan
 */
class RightTriangle extends GeometricObject{
    private double base;
    private double height;
    private double hypotenuse;
    
    public RightTriangle(double newBase, double newHeight, double newHyp) {
        base = newBase;
        height = newHeight;
        hypotenuse = newHyp;
    }
    
    double area() {
        return (.5 * base * height);
    }
    
    double getPerimeter() {
        return (base + height + hypotenuse);
    }
    
    double getVolume() {
        return -1;
    }
}
